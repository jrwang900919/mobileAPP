package com.example.w5

import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btnToast = findViewById<Button>(R.id.btnToast)
        val btnSnackbar = findViewById<Button>(R.id.btnSnackerBar)
        val btnDialog1 = findViewById<Button>(R.id.btnDialog1)
        val btnDialog2 = findViewById<Button>(R.id.btnDialog2)
        val btnDialog3 = findViewById<Button>(R.id.btnDialog3)

        val item = arrayOf("皮卡丘", "噴火龍","水箭龜", "卡比", "雙彈瓦斯")

        btnToast.setOnClickListener{
            showToast("去吧！就決定是你了")
        }
        btnSnackbar.setOnClickListener{
            Snackbar.make(it,"你已經收服超夢",Snackbar.LENGTH_LONG)
                .setAction("我知道了"){showToast("玩家已經收服新的寶可夢")}.show()
        }
        btnDialog1.setOnClickListener{
            AlertDialog.Builder(this)
                .setTitle("午餐約")
                .setMessage("你要跟老師吃飯嗎")
                .setNeutralButton("算了吧..."){DialogInterface,which->showToast("it'ok")}
                    .setNegativeButton("拒絕"){DialogInterface,which->showToast("老師不開心")}
                .setPositiveButton("勉為其難同意"){DialogInterface,which->showToast("保證歐趴")}.show()

        }
        btnDialog2.setOnClickListener{
            AlertDialog.Builder(this).setTitle("列表")
                .setItems(item){DialogInterface,i->showToast("你選的是${item[i]}")}

        }

        btnDialog3.setOnClickListener{
            var position =0
            AlertDialog.Builder(this)
                .setTitle("午餐約")
                .setSingleChoiceItems(item,0){DialogInterface,i->position=i}
                .setPositiveButton("確定"){DialogInterface,which->showToast("你選的是${item[position]}")}
                .show()
        }

    }
    private fun showToast(msg:String){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()
    }
}